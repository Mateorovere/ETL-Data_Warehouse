USE TP_DW

DECLARE @StartDate DATE = '2000-01-01';
DECLARE @EndDate DATE = '2030-12-31';

WHILE @StartDate <= @EndDate
BEGIN
    INSERT INTO d_Fecha(Fecha, A�o, Mes, Quarter, Dia_Semana, Dia_Mes, Semana_Mes, Feriado)
    VALUES (
        @StartDate, -- FullDate
        YEAR(@StartDate), 
        MONTH(@StartDate),
        DATEPART(QUARTER, @StartDate), 
        DATEPART(WEEKDAY, @StartDate), 
        DAY(@StartDate), 
        DATEPART(WEEK, @StartDate) - DATEPART(WEEK, DATEADD(MONTH, DATEDIFF(MONTH, 0, @StartDate), 0)) + 1, 
        0 
    );

    SET @StartDate = DATEADD(DAY, 1, @StartDate);
END;

-- agregar un agrupado por fechas de nacimiento de a 5 a�os

use TP_DW
ALTER TABLE d_clientes
ADD Grupo_A�o_Nacimiento VARCHAR(50);

UPDATE d_clientes
SET Grupo_A�o_Nacimiento = CONCAT(' (',
    (SELECT MIN(Fecha_Nacimiento) FROM d_clientes WHERE CEILING((Fecha_Nacimiento - 1900) / 5) = CEILING((p.Fecha_Nacimiento - 1900) / 5)),
    '-',
    (SELECT MAX(Fecha_Nacimiento) FROM d_clientes WHERE CEILING((Fecha_Nacimiento - 1900) / 5) = CEILING((p.Fecha_Nacimiento - 1900) / 5))
    )
FROM d_clientes p;
